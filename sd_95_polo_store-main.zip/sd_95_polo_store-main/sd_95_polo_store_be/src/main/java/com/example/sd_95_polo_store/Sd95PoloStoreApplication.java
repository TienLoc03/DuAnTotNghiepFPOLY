package com.example.sd_95_polo_store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sd95PoloStoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(Sd95PoloStoreApplication.class, args);
    }

}
