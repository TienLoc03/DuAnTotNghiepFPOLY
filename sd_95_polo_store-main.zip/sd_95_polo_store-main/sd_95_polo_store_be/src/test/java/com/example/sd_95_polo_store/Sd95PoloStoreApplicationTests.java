package com.example.sd_95_polo_store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sd95PoloStoreApplicationTests {

    @Test
    void contextLoads() {
    }

}
